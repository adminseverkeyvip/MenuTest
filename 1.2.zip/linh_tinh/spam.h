#import <Foundation/Foundation.h>

@interface Spam : NSObject

- (void)startSpam;

@end